# Installation — Plugin Aurentia v2

## Pré-requis

- **Claude Code** installé en CLI ou via IDE (VS Code, Cursor, JetBrains)
  Pour installer Claude Code : voir [docs Anthropic](https://docs.claude.com/en/docs/claude-code)
- **Node.js** (pour les MCPs servers bundlés)

## Méthode 1 — Installation locale (recommandé pour démarrer)

```bash
# Cloner ou copier le dossier aurentia-plugin où tu veux
cp -R aurentia-plugin ~/.claude/plugins/

# Vérifier la structure
ls ~/.claude/plugins/aurentia-plugin/
# → .claude-plugin/  .mcp.json  commands/  README.md  INSTALLATION.md  skills/
```

Puis dans Claude Code, lance :
```
/aurentia
```

## Méthode 2 — Via marketplace (quand le plugin sera publié)

```
/plugin marketplace add <url-du-marketplace>
/plugin install aurentia
```

## Vérification

Lance Claude Code et tape :

```
/aurentia
```

Tu dois voir la présentation des 10 skills + le router.

Teste ensuite une slash command :
```
/devis Site vitrine pour une boulangerie de Cavaillon, budget 4500€
```

## Activation des MCPs

Le plugin embarque un `.mcp.json` minimal avec le serveur **filesystem** officiel
d'Anthropic (lecture/écriture dans `~/Documents` et `~/Desktop`).

Pour activer :

```bash
# Au premier lancement, Claude Code te demandera de valider les MCPs
# Accepte le `filesystem` server
```

Pour ajouter d'autres MCPs (PDF, Stripe, Notion, etc.), édite `.mcp.json`.

Exemples d'ajouts utiles selon ton usage :

```json
{
  "mcpServers": {
    "filesystem": {...},
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp"]
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": { "GITHUB_PERSONAL_ACCESS_TOKEN": "ghp_..." }
    }
  }
}
```

## Personnalisation

Le plugin est conçu pour être éditable. Si tu veux adapter un skill à ton activité
(ton style commercial, tes templates de factures, ton secteur), édite directement le
`SKILL.md` correspondant.

Recommandé : avant d'éditer, fais un git commit pour pouvoir revenir en arrière.

## Mise à jour

```bash
# Si installé via clonage local
cd ~/.claude/plugins/aurentia-plugin
git pull   # si tu as fait git clone
```

## Support

Questions, retours : [aurentia.agency](https://aurentia.agency)
