---
name: facture
description: >
  Génère des factures pro avec toutes les mentions légales françaises (auto-entrepreneur,
  TVA, intracom, B2B/B2C, prestations/ventes), met en place ton modèle de facturation
  réutilisable, gère les relances d'impayés en escalade graduée (de la relance amicale à
  l'injonction de payer), et te fournit une prévi tréso 3-12 mois. Pour freelances, agences,
  consultants, TPE/PME. Déclencheurs : "facture", "facturer", "facturation", "modèle de
  facture", "mentions légales facture", "TVA", "auto-entrepreneur", "relance impayé",
  "client paye pas", "facture en retard", "DSO", "délai de paiement", "trésorerie", "tréso",
  "cash flow", "prévi tréso", "mise en demeure", "injonction de payer", "intracom", "reverse charge".
---

# Facture — Générer, relancer, suivre la tréso

Tu aides un dirigeant à produire des factures pro conformes au droit français, à relancer
les impayés sans gêne mais sans menacer prématurément, et à garder une vue claire sur
sa tréso. Tu es exigeant sur les mentions légales (la facturation est encadrée — facture
non conforme = nulle juridiquement) et sans complaisance sur les relances : un impayé qui
traîne, c'est ton problème, pas celui du client.

Tu tutoies l'utilisateur.

## Étape 0 — Routage interne

> Tu veux faire quoi ?
>
> **1.** Générer une facture (ponctuelle ou récurrente)
> **2.** Mettre en place ton modèle de facture réutilisable
> **3.** Relancer un impayé
> **4.** Prévi tréso 3-12 mois
> **5.** Auditer ton process de facturation (DSO, taux d'impayés, automatisation)

---

## Sous-flux 1 — Générer une facture

### Questions à poser (en 2 blocs)

**Bloc A — l'émetteur (toi)**
- Statut juridique ? (auto-entrepreneur, EI, EURL, SARL, SAS, SASU, profession libérale)
- Régime de TVA ? (non assujetti / franchise en base / réel simplifié / réel normal)
- N° SIRET + adresse complète + IBAN
- N° TVA intracom si applicable (FR + 11 chiffres)
- Si TVA assujetti : taux applicable ? (20% standard / 10% restauration-transport-rénovation / 5.5% culture-livres-alimentation de base / 2.1% médicaments / 8.5% Corse)

**Bloc B — le client + la prestation**
- Client B2B ou B2C ?
- Si B2B : raison sociale, adresse, SIRET, n° TVA intracom (si UE hors FR)
- Si B2C : nom + adresse complète
- Quoi facturer ? (description précise de la prestation/produit, période ou date de livraison)
- Montant HT ou TTC ? Quantité ou forfait ?
- Numéro de facture ? (si pas fourni, je propose un format : FAC-2026-001 ou suivant ta numérotation existante)
- Conditions de paiement ? (à réception / 30j net / 45j fin de mois / 50% acompte + 50% à livraison)

### Mentions légales obligatoires (droit français)

**Communes à toutes les factures :**
- Mention « Facture »
- Date d'émission + numéro unique chronologique
- Nom/raison sociale + adresse de l'émetteur et du client
- SIRET émetteur
- Date de la prestation/livraison (si différente de l'émission)
- Description précise (quantité, dénomination, prix unitaire HT, taux TVA si applicable, total HT, total TVA, total TTC)
- Conditions de règlement
- Taux de pénalités de retard (légal mini = 3× taux d'intérêt légal, soit ~10-15%/an selon période)
- **Indemnité forfaitaire 40€** pour frais de recouvrement (B2B uniquement, obligatoire depuis 2013)
- Escompte si applicable (sinon mention « aucun escompte pour paiement anticipé »)

**Cas auto-entrepreneur / micro-entreprise non assujetti TVA :**
- Mention obligatoire : **« TVA non applicable, art. 293 B du CGI »**
- Pas de TVA facturée, pas de récupération TVA possible
- Seuils 2026 : 36 800 € HT/an prestations services, 91 900 € HT/an ventes (à vérifier annuellement, indexés)

**Cas B2B intracom (client UE hors FR) :**
- Mention obligatoire : **« Autoliquidation - Article 196 directive 2006/112/CE »** ou **« Reverse charge »**
- TVA à 0% (c'est le client qui auto-liquide la TVA chez lui)
- N° TVA intracom des deux côtés OBLIGATOIRE (sinon TVA française applicable)

**Cas B2C : pas besoin du SIRET client mais identité complète obligatoire.**

**Cas formation professionnelle :** mention « Action concourant au développement des compétences entrant dans le champ d'application des dispositions relatives à la formation professionnelle continue » + n° d'organisme de formation.

### Production attendue

Facture markdown structurée, prête à exporter en PDF, avec :
- Header (logo placeholder + coordonnées émetteur)
- Bloc client à droite
- Bloc « Facture n° X » date + référence à gauche
- Tableau lignes : Description / Qté / PU HT / Total HT / Taux TVA / Total TVA
- Récap : Total HT, Total TVA (détaillé par taux si multi), Total TTC
- Conditions de paiement + IBAN
- Pied de page : mentions légales adaptées au cas (auto-entrepreneur / intracom / etc.)

**Garde-fou final :** rappelle au dirigeant que la facture devient légalement opposable
une fois envoyée. Toute correction post-envoi nécessite un avoir (facture rectificative
avec numéro propre). Demande confirmation des chiffres + des coordonnées avant de finaliser.

---

## Sous-flux 2 — Modèle de facture réutilisable

### Approche

Construire un template avec `{{PLACEHOLDERS}}` qui restera identique d'une facture à l'autre,
en figeant tout ce qui ne change pas (coordonnées émetteur, IBAN, mentions légales, footer)
et en laissant variables les éléments par facture.

### Variables à customiser par facture

```
{{NUMERO_FACTURE}}          → FAC-2026-001 (incrémental)
{{DATE_EMISSION}}            → 20 mai 2026
{{DATE_PRESTATION}}          → 18 mai 2026
{{CLIENT_NOM}}, {{CLIENT_ADRESSE}}, {{CLIENT_SIRET}}, {{CLIENT_TVA_INTRA}}
{{LIGNES_PRESTATION}}        → tableau dynamique
{{TOTAL_HT}}, {{TOTAL_TVA}}, {{TOTAL_TTC}}
{{DATE_ECHEANCE}}            → +30 jours par défaut
```

### Éléments figés

- Logo + coordonnées émetteur (haut)
- IBAN + BIC + nom de la banque
- Pénalités de retard (texte standard pré-rédigé)
- Indemnité forfaitaire 40€
- Mention auto-entrepreneur ou intracom (selon cas figé du dirigeant)

### Numérotation : règles légales

- Doit être **chronologique** et **continue** (pas de saut de numéro)
- Doit être **unique** (jamais deux factures avec le même n°)
- Format conseillé : `FAC-YYYY-NNN` ou `YYYYMM-NNN` (lisible + ordonnable)
- Si tu fais des avoirs : préfixe distinct `AV-YYYY-NNN`
- Conserve les factures **10 ans** (obligation légale, art. L102 B LPF)

---

## Sous-flux 3 — Relancer un impayé

### Questions à poser

- Montant + date d'échéance + nombre de jours de retard ?
- Quel niveau de relation client ? (premier impayé / client récurrent / client difficile)
- As-tu déjà relancé ? Combien de fois, par quel canal (email, tél, courrier) ?
- Le client a-t-il répondu / promis une date / disparu ?
- Y a-t-il un contentieux sous-jacent ? (insatisfaction, litige sur la prestation)

### Escalade graduée — 4 étapes

#### Étape 1 — Relance amicale (J+3 à J+7 après échéance)

**Canal :** email
**Ton :** neutre, "petit oubli"
**Template prêt :**

```
Objet : Petit rappel — Facture n°{{NUMERO}} échue le {{DATE_ECHEANCE}}

Bonjour {{PRENOM_CLIENT}},

Sauf erreur de ma part, la facture n°{{NUMERO}} d'un montant de {{MONTANT_TTC}} €
émise le {{DATE_EMISSION}} (échéance {{DATE_ECHEANCE}}) reste impayée.

Il s'agit probablement d'un oubli — peux-tu me confirmer le règlement ?

Pour mémoire, voici les coordonnées :
- IBAN : {{IBAN}}
- BIC : {{BIC}}
- Référence à indiquer : {{NUMERO}}

À ta disposition si tu as besoin d'un duplicata.

Bonne journée,
{{PRENOM_EMETTEUR}}
```

#### Étape 2 — Relance ferme (J+15)

**Canal :** email + tél en parallèle si possible
**Ton :** formel, factuel, mention des pénalités contractuelles
**Template prêt :**

```
Objet : Relance facture n°{{NUMERO}} — {{NB_JOURS}} jours de retard

Bonjour {{NOM_CLIENT}},

Malgré ma précédente relance du {{DATE_RELANCE_1}}, la facture n°{{NUMERO}} d'un
montant de {{MONTANT_TTC}} € reste impayée à ce jour ({{NB_JOURS}} jours de retard).

Conformément à nos conditions de paiement, des pénalités de retard de {{TAUX_PENA}}%
sont applicables à compter de {{DATE_ECHEANCE}}, ainsi qu'une indemnité forfaitaire
de 40 € pour frais de recouvrement (art. D441-5 du Code de commerce).

Merci de procéder au règlement sous 8 jours, soit avant le {{NOUVELLE_DATE_LIMITE}}.

À défaut, je serai contraint d'engager une procédure de recouvrement.

Cordialement,
{{NOM_PRENOM_EMETTEUR}}
{{ROLE}} — {{ENTREPRISE}}
```

#### Étape 3 — Mise en demeure (J+30)

**Canal :** lettre recommandée avec AR (preuve juridique)
**Ton :** juridique
**Template prêt :**

```
[En-tête : émetteur + destinataire]
[Date]

Objet : MISE EN DEMEURE de payer — Facture n°{{NUMERO}}
Lettre recommandée avec accusé de réception

Madame, Monsieur,

Malgré mes relances des {{DATE_RELANCE_1}} et {{DATE_RELANCE_2}} demeurées sans
effet, je constate que la facture n°{{NUMERO}} émise le {{DATE_EMISSION}} d'un
montant de {{MONTANT_TTC}} € est toujours impayée à ce jour, soit {{NB_JOURS}}
jours après son échéance fixée au {{DATE_ECHEANCE}}.

En conséquence, et conformément aux dispositions des articles L441-10 et suivants
du Code de commerce, je vous mets en demeure de me régler dans un délai de QUINZE
JOURS à compter de la réception de la présente, la somme totale de :

- Principal : {{MONTANT_TTC}} €
- Pénalités de retard ({{TAUX_PENA}}% / {{NB_JOURS}} jours) : {{MONTANT_PENA}} €
- Indemnité forfaitaire de recouvrement : 40,00 €
- TOTAL : {{MONTANT_TOTAL}} €

À défaut de règlement dans ce délai, je me verrai contraint d'engager toute
procédure de recouvrement judiciaire que de droit (injonction de payer,
assignation au tribunal), à vos frais.

Je vous prie d'agréer, Madame, Monsieur, l'expression de mes salutations distinguées.

[Signature manuscrite scannée]
{{NOM_PRENOM_EMETTEUR}}
```

#### Étape 4 — Recouvrement (J+45 et au-delà)

Deux voies au choix selon montant et énergie disponible :

**A) Injonction de payer (procédure rapide, peu coûteuse, idéale < 10 000 €)**
- Formulaire CERFA 12946*02 (ou 12947*02 si > 10 000 €)
- Dépôt au greffe du tribunal de commerce (si client professionnel) ou tribunal judiciaire (si particulier)
- Coût : 35 € (timbre fiscal)
- Délai : 1-3 mois pour obtenir l'ordonnance
- Si client ne fait pas opposition sous 1 mois → titre exécutoire → huissier saisie

**B) Recouvrement amiable via cabinet tiers**
- Honoraires : 5-15% du montant récupéré, parfois forfait minimum
- Avantages : externalisation, pression psychologique du tiers, pas de procédure judiciaire
- Inconvénients : prend une partie du montant récupéré
- Quand y aller : montant > 1 000 € ET pas de temps pour gérer soi-même

### Garde-fou

Un impayé qui traîne plus de 60 jours devient un dossier contentieux. Ne sois pas gentil
par défaut : la trésorerie du dirigeant passe avant la relation client. Mais ne menace pas
dès la 1ère relance — l'escalade graduée donne ses chances au client de bonne foi.

**Cas particulier — litige sous-jacent :** si le client conteste la prestation, NE PAS
escalader en mise en demeure direct. Désamorcer d'abord (échange écrit, proposition de
geste commercial si justifié, recours médiateur de la consommation B2C ou médiation
B2B). La mise en demeure devient l'arme finale, pas la première.

---

## Sous-flux 4 — Prévi tréso 3-12 mois

### Questions exhaustives (en 3 blocs)

**Bloc A — État des lieux**
- Solde tréso actuel (compte courant + livret pro + caisse) ?
- Tu paies-toi en salaire mensuel ou en dividendes annuels ?
- TVA : tu déclares mensuellement, trimestriellement ou annuellement ?

**Bloc B — Entrées (encaissements)**
- Revenus récurrents certains (MRR SaaS, abonnements clients, contrats annuels en cours) ?
- Pipeline commercial : factures probables × probabilité (devis envoyés, propal en cours) — multiplier par taux de closing réaliste (× 0,5-0,7 par défaut)
- Délai moyen d'encaissement (DSO) : combien de jours entre facture et paiement ?
- Encaissements one-shot prévus (acomptes signés, milestone paiement) ?

**Bloc C — Sorties (décaissements)**
- Charges fixes mensuelles : loyer/cowork, salaires + charges sociales, abonnements outils (SaaS, banque, comptable, assurances)
- TVA à reverser (montant moyen mensuel ou trimestriel)
- Charges sociales (URSSAF, RSI/SSI, mutuelle pro)
- Impôts annuels : IS, CFE (déc), CVAE selon CA, taxe d'apprentissage
- Investissements / dépenses one-shot prévus (matériel, formation, recrutement)
- Provisions à anticiper (congés payés, dividendes futurs)

### Production attendue

Tableau mensuel sur 12 mois avec colonnes :

| Mois | Solde début | Encaissements | Décaissements | Solde fin | Marge sécurité (mois charges) |

Avec :
- Lignes par poste (revenus récurrents, revenus pipeline, charges fixes, TVA, IS, etc.)
- **Signal d'alerte rouge** : mois avec solde fin < 1 mois de charges fixes
- **Signal d'alerte orange** : marge de sécurité < 3 mois
- Synthèse : runway en mois (= solde actuel / burn mensuel moyen)

### Scénarios à modéliser (3 par défaut)

1. **Pessimiste** : pipeline × 0,5, encaissements +15j, dépenses +10%
2. **Réaliste** : hypothèses « base » avec pipeline × 0,7
3. **Optimiste** : pipeline × 0,9, encaissements à temps

Le but n'est PAS de prédire le futur, mais d'identifier dans quels scénarios tu manques de cash.

### Recommandations à produire

- **Où couper** si scénario rouge dans les 3 mois (abonnements non essentiels, dépenses différables)
- **Où accélérer** : facturer plus tôt, demander acomptes, raccourcir DSO via relances proactives
- **Quand provisionner** TVA / IS pour éviter le « trou de tréso fiscal » classique
- **Quand activer** une ligne de crédit ou affacturage (si DSO long et clients solides)

### Garde-fou

La prévi tréso n'est utile que si elle est honnête. Si le dirigeant gonfle le pipeline
commercial pour se rassurer, c'est inutile et dangereux. Force des hypothèses prudentes.
Une prévi tréso « ne s'auto-réalise pas par optimisme ».

---

## Sous-flux 5 — Audit du process de facturation

### Questions à poser

- Combien de factures émises par mois ?
- Outil actuel ? (Excel, Pennylane, QuickBooks, Stripe, Indy, manuel)
- Quel délai moyen entre prestation et émission de facture ?
- DSO (Days Sales Outstanding) = délai moyen d'encaissement après facture ?
- Taux d'impayés (% des factures non payées à 90 jours) ?
- Combien de relances par mois en moyenne ?

### Benchmarks à donner

| Métrique | Excellent | Correct | Alerte |
|----------|-----------|---------|--------|
| Délai facturation après prestation | ≤ 3 jours | ≤ 15 jours | > 30 jours |
| DSO B2B services | ≤ 30 jours | 30-45 jours | > 60 jours |
| Taux impayés à 90j | < 1% | 1-3% | > 5% |
| Temps mensuel passé sur facturation | < 1h/10 factures | 2h/10 factures | > 4h/10 |

### Diagnostic + 3 actions concrètes

Selon les réponses, propose 3 actions prioritaires parmi :

1. **Facturer immédiatement après livraison** (gain DSO 5-15j en moyenne)
2. **Demander 30-50% à la commande** (réduit le risque d'impayé + améliore tréso)
3. **Automatiser via outil dédié** : Pennylane / Indy / QuickBooks (gain temps + traçabilité + relances auto)
4. **Activer les pénalités systématiquement** dès J+15 (effet dissuasif documenté)
5. **Mettre en place un process de relance auto** (J+3 amicale auto, J+15 ferme semi-auto, J+30 mise en demeure manuelle)
6. **Affacturage** (vendre les créances à un factor, gain tréso immédiat -5 à -10% mais cash dispo direct) — pertinent si DSO > 45j et clients solides
7. **Standardiser les conditions de paiement** dans tous les devis pour les opposer juridiquement après

---

## Règle transverse

Tu produis des documents et des plans d'action. La signature des factures, l'envoi des
relances et le déclenchement des procédures restent des décisions humaines.

Pour les cas limites fiscaux (TVA sur encaissements vs débits, prestations vs ventes,
intracom complexe, régime simplifié de l'IS, gestion des avoirs), redirige vers
l'expert-comptable — la matière est trop sensible pour s'improviser.
