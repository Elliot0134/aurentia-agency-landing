---
name: devis
description: "Générateur de devis, propositions commerciales et cahiers des charges pour tout type de prestation B2B (services, conseil, dev, formation, agence, freelance). Optimisé pour les projets sur mesure incluant des composantes tech / IA. Utiliser dès que l'utilisateur mentionne : devis, quote, proposition commerciale, propal, cahier des charges, CDC, specs, spécifications, estimation de prix, chiffrage, combien ça coûte, pricing projet, brief technique, scope projet, scope of work, SOW, nouveau projet client, onboarding projet, cahier des charges fonctionnel, cahier des charges technique, estimation budget, calcul prix, tarif, forfait. Aussi quand l'utilisateur décrit un projet client à chiffrer, veut structurer une proposition, ou demande les informations nécessaires avant de démarrer."
---

# Devis & Cahier des Charges

Skill pour générer des devis professionnels, propositions commerciales et cahiers des charges complets pour tout projet sur devis (services, conseil, agence, freelance). Particulièrement riche pour les projets d'implémentation tech / IA — mais adaptable à toute prestation B2B.

## Vue d'ensemble

Ce skill guide l'utilisateur à travers un processus structuré en **3 phases** :

1. **Phase 1 — Qualification du projet** : Collecte des informations clés
2. **Phase 2 — Génération** : Calcul du pricing et structuration des documents
3. **Phase 3 — Production** : Génération des fichiers finaux (PDF + DOCX)

---

## Phase 1 — Qualification du projet

**RÈGLE D'OR : poser un MAXIMUM de questions.** Plus on comprend le projet en amont, plus le devis/CDC sera précis et le client impressionné. Ne jamais se contenter de réponses vagues — creuser, reformuler, challenger. Poser 3-4 questions par bloc, avancer progressivement.

### Étape 1.1 : Routage initial

Commencer par demander à l'utilisateur ce qu'il souhaite générer :

```
Pour ton projet, tu as besoin de :
- [ ] Un devis uniquement (pricing + scope)
- [ ] Un cahier des charges (CDC) uniquement (specs détaillées)
- [ ] Les deux : devis + CDC (complet)
- [ ] Une proposition commerciale (devis enrichi de pitch + méthodologie)
- [ ] Un scope of work (SOW) signable
```

### Étape 1.2 : Collecte exhaustive — avancer par blocs

**Bloc 1 — Le client**
- Nom de l'entreprise cliente
- Site web (web search possible pour enrichir le contexte)
- Secteur d'activité
- Taille (solo, TPE, PME, ETI, GE)
- Contact principal (nom, rôle, email)
- Outils en place (Excel, CRM, ERP, SaaS connus)
- Niveau tech (non-tech, basique, tech-savvy)

**Bloc 2 — Le problème à résoudre**
- Problème principal du client (en 2-3 phrases)
- Comment géré aujourd'hui (process manuel, outil, rien)
- Conséquences actuelles (perte temps, erreurs, coût, frustration)
- Résultat attendu (KPI, gain temps, automatisation)
- Événement déclencheur (croissance, réglementation, levée)

**Bloc 3 — Vue d'ensemble du projet**
- Type de projet (SaaS B2B, app interne, workflow IA, site vitrine, refonte, audit, formation, conseil)
- Utilisateurs prévus (rôles, nombre estimé)
- Features clés souhaitées (lister)
- Brief / CDC existant ? (même partiel)
- Contraintes métier (RGPD renforcé, secteur réglementé, accessibilité)

**Bloc 4 — Workflows & Automatisations (creuser à fond si projet IA / tech)**

Pour CHAQUE workflow identifié :
- **Trigger** : action utilisateur, événement, cron, webhook ?
- **Input** : quelles données, d'où ?
- **Étapes** : traitement, appel IA, transformation, validation
- **Output** : notification, BDD, fichier généré, action externe
- **Dépendances** : entre workflows ?
- **Fréquence + volume**
- **Gestion d'erreur** : si une étape échoue ?

**Mapper les dépendances** entre workflows pour le CDC.

**Bloc 5 — Intégrations tierces**
Pour CHAQUE intégration :
- Service / API ?
- Sens du flux (envoi, réception, bidirectionnel)
- Fréquence sync (temps réel, batch, à la demande)
- Compte/accès API du client en place ?
- Limitations connues (rate limits, coûts)

**Bloc 6 — Complexité tech / IA & Design**
- Niveau IA : chatbot simple, RAG avancé, multi-agents, custom (fine-tuning)
- Modèles envisagés (Claude, GPT, Gemini, open source)
- IA front (interaction user) ou back-office ?
- UI/UX : standard (shadcn/ui) ou custom avancé
- MCP server custom nécessaire ?

**Bloc 7 — Délais & contraintes**
- Date de démarrage souhaitée
- Date de livraison cible (et flexibilité)
- Phases / milestones imposés (validation client, démo, etc.)
- Contraintes externes (réglementation, lancement marché)

**Bloc 8 — Budget**
- Budget alloué / fourchette / "voyons d'abord le chiffrage" ?
- Modalité de paiement préférée (forfait, milestones, mensuel)
- Acompte ?

---

## Phase 2 — Génération

### Pricing — méthode forfait pour projet sur mesure

**Approche par charge :**
1. Estimer charge en jours-hommes par phase (cadrage, design, dev, recette, mise en prod)
2. Multiplier par TJM cible (consulting tech : 600-1200€/jour selon expertise)
3. Ajouter buffer 15-25% (aléas)
4. Vérifier marge brute > 30%

**Approche par valeur (alternative pour gros projets) :**
1. Estimer le gain business pour le client (CA additionnel, économies, gain temps × valeur horaire)
2. Pricing à 10-25% de la valeur créée
3. Justifier par ROI dans la propal

### Structure devis

```
═══════════════════════════════════════════
DEVIS N°{{NUMERO}} — {{NOM_PROJET}}
═══════════════════════════════════════════
Émis le : {{DATE}}
Valable jusqu'au : {{DATE +30J}}

ÉMETTEUR : {{Toi — raison sociale, adresse, SIRET, TVA intra}}
CLIENT : {{Raison sociale, adresse, SIRET, contact}}

OBJET : {{Description du projet en 1 phrase}}

DÉTAIL DU CHIFFRAGE
| Phase                  | Charge (j) | TJM   | Sous-total HT |
|------------------------|-----------|-------|---------------|
| Cadrage & specs        | X         | 800   | X €           |
| Design UI/UX           | X         | 700   | X €           |
| Développement          | X         | 700   | X €           |
| Tests & recette        | X         | 700   | X €           |
| Mise en production     | X         | 600   | X €           |
| Formation utilisateurs | X         | 600   | X €           |
| TOTAL HT               |           |       | XXX €         |
| TVA 20%                |           |       | XX €          |
| TOTAL TTC              |           |       | XXX €         |

CONDITIONS DE PAIEMENT
- 30% à la commande
- 40% à mi-projet (livraison phase X)
- 30% à livraison finale + recette acceptée
- Délai de paiement : 30 jours net (pénalités 3× taux légal + indemnité 40€ si retard B2B)

INCLUS
- {{Liste précise}}

NON INCLUS (sera facturé en sus)
- {{Liste — hébergement, outils tiers, formations supplémentaires, etc.}}

GARANTIE / MAINTENANCE
- Garantie correctifs : 3 mois post-livraison
- Maintenance évolutive : optionnelle, sur devis ou contrat

[Signature client] — [Signature prestataire]
```

### Structure CDC (cahier des charges)

```
═══════════════════════════════════════════
CAHIER DES CHARGES — {{NOM_PROJET}}
═══════════════════════════════════════════
Version : 1.0
Date : {{DATE}}
Rédacteur : {{NOM}}
Validé par : {{CLIENT}}

1. CONTEXTE
   1.1 Présentation du client
   1.2 Problème adressé
   1.3 Objectifs business

2. PÉRIMÈTRE FONCTIONNEL
   2.1 Description générale
   2.2 Utilisateurs cibles + cas d'usage
   2.3 Liste des features (priorisées MoSCoW)
   2.4 Out of scope explicite

3. SPÉCIFICATIONS DÉTAILLÉES
   3.1 Parcours utilisateur principaux (user flows)
   3.2 Workflows automatisés détaillés (cf. Bloc 4 questions)
   3.3 Intégrations tierces (cf. Bloc 5)
   3.4 Gestion des erreurs et cas limites

4. ARCHITECTURE TECHNIQUE
   4.1 Stack technique recommandée
   4.2 Schéma d'architecture
   4.3 Modèle de données (entités, relations)
   4.4 Sécurité & RGPD

5. DESIGN
   5.1 Charte graphique (couleurs, typo, ton)
   5.2 Composants UI principaux
   5.3 Responsive / accessibilité

6. PLANNING
   6.1 Phases & milestones
   6.2 Calendrier détaillé
   6.3 Critères de validation par phase

7. GOUVERNANCE PROJET
   7.1 Équipe & rôles
   7.2 Cadence de réunion
   7.3 Outils de collaboration

8. CRITÈRES DE RECETTE
   8.1 Liste des tests à valider
   8.2 Conditions d'acceptation

9. ANNEXES
```

---

## Phase 3 — Production

Génération du document final selon le besoin :
- **Markdown** par défaut (peut être converti facilement)
- **PDF** via Pandoc ou print-to-pdf navigateur (si MCP PDF tools dispo)
- **DOCX** via Pandoc

Le devis et le CDC sont fournis en 2 fichiers séparés. La proposition commerciale fusionne devis + extrait CDC + pitch.

---

## Garde-fous globaux

- **Forfait sans cadrage = catastrophe.** Si l'utilisateur veut un devis ferme sans avoir clarifié le scope, refuse et propose une phase de cadrage payante (1-3 jours).
- **Buffer obligatoire** : au moins 15-25% sur la charge estimée. Sans ça, tu perds de l'argent au 1er aléa.
- **CDC validé par écrit avant démarrage** : sinon scope creep garanti.
- **Pour projets > 20K€** : suggérer un avocat pour le contrat associé (le skill `contrat` peut produire la base, mais la relecture pro est conseillée à ce montant).
