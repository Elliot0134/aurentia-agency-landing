# The Accelerator Lens: How Top Programs Evaluate Companies

## Table of Contents
1. [Y Combinator](#yc)
2. [Techstars](#techstars)
3. [500 Global & Pirate Metrics](#500-global)

---

<a name="yc"></a>
## 1. Y Combinator

### Selection Criteria (1.5–2% acceptance rate)

YC prioritizes **founding team above all**:
- Extraordinary specific achievements (not generic "leadership experience")
- Complementary skills (technical + business, not two business people)
- Fair equity splits (near-equal signals mutual respect; unfair splits often predict conflict)
- Technical co-founders (strongly preferred — can you build v1 without outsourcing?)

They care less about the idea itself and more about **what the idea reveals about the founders' thinking.** A weird-sounding idea that shows deep insight into a real problem beats a "safe" idea that everyone understands.

### The Current YC Deal

$500K total:
- $125K for 7% equity
- $375K uncapped SAFE

### Batch Structure

- Weekly **growth targets** (5–7% revenue growth per week is the bar)
- 1:1 mentorship with a **Group Partner**
- **Office hours** with visiting partners and alumni
- Culminates in **Demo Day** — pitching to hundreds of investors

### YC's 2025–2026 Requests for Startups

Key themes they're actively funding:
- AI agents and multi-agent infrastructure
- AI-native enterprise software
- "The first 10-person, $100B company" (maximal leverage through AI)
- Open-source AI tools and infrastructure
- Vertical AI applications (healthcare, legal, finance)

### Michael Seibel's Core Advice

1. **Launch immediately** — "Launch something bad quickly." Perfection is the enemy of learning.
2. **Get 10 users who love you** rather than 1,000 who are ambivalent. Depth of love beats breadth of lukewarm interest.
3. **Never confuse fundraising rounds with milestones.** Raising a Series A is not an achievement — it's a tool. The milestones are product-market fit, sustainable unit economics, and a growing customer base.

---

<a name="techstars"></a>
## 2. Techstars

### Selection Weighting

- **Team: 50% of the decision** (highest weight of any major accelerator)
- Key team factors: coachability (will they listen and adapt?), complementary skills, grit
- "Give First" philosophy — the culture expects founders to help each other before asking for help

### Mentorship Model

Techstars is mentorship-driven rather than lecture-driven:
- 10,000+ mentors in the network
- **"Mentor Madness"** in the first weeks — intense speed-dating with mentors to find the best matches
- Each startup ends up with 2–3 core mentors who provide ongoing guidance

### The Deal

- $20K stipend
- Optional $100K convertible note
- Total: up to ~9% equity

### What Techstars Optimizes For

Unlike YC's "growth at all costs" culture, Techstars emphasizes:
- Sustainable business model clarity
- Customer discovery and validation
- Network effects of the mentor community
- Long-term mentor relationships (not just the batch period)

---

<a name="500-global"></a>
## 3. 500 Global & Pirate Metrics (AARRR)

### Dave McClure's Pirate Metrics Framework

The AARRR framework spans the full user lifecycle:

```
ACQUISITION → ACTIVATION → RETENTION → REFERRAL → REVENUE
```

| Stage | Question | Key Metrics |
|-------|----------|-------------|
| **Acquisition** | How do people find you? | Traffic sources, CAC by channel, signup rate |
| **Activation** | Do they experience core value? | Onboarding completion, "aha moment" rate, Time-to-Value |
| **Activation** | Do they experience core value? | Onboarding completion, "aha moment" rate, Time-to-Value |
| **Retention** | Do they come back? | DAU/MAU, cohort retention curves, churn rate |
| **Referral** | Do they tell others? | NPS, viral coefficient, referral rate |
| **Revenue** | Do they pay? | Conversion rate, ARPU, LTV |

### The Critical Insight

Most early-stage companies focus on Acquisition first. This is wrong.

**The correct priority order:**
1. **Retention** — if people don't come back, acquiring more is pouring water into a sieve
2. **Activation** — if people don't experience the core value, they'll never retain
3. **Revenue** — once they retain, figure out the monetization
4. **Referral** — satisfied, retained users become the growth engine
5. **Acquisition** — scale what works

A product with loads of signups but terrible activation isn't a product — it's a churn machine. Fix activation and retention before spending a dollar on acquisition.

### Practical Application

For each AARRR stage, identify:
1. The current metric and benchmark
2. The biggest drop-off (where in the funnel are you losing people?)
3. The root cause of the drop-off
4. 2–3 experiments to improve it

Run experiments in priority order (retention first, then activation, then revenue/referral, then acquisition). Measure weekly.

### 500 Global's Approach

- Early-stage focused (pre-seed and seed)
- Invests in ~200+ companies per year
- Strong focus on emerging markets and underrepresented founders
- Uses AARRR as the primary diagnostic framework for portfolio companies
- Portfolio support emphasizes metrics discipline and growth hacking methodology
