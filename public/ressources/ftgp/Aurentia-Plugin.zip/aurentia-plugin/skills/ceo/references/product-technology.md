# Product & Technology Frameworks

## Table of Contents
1. [Steve Jobs' Product Philosophy](#jobs)
2. [Eric Ries' Lean Startup](#lean-startup)
3. [Marty Cagan's Empowered Product Teams](#cagan)
4. [Product-Market Fit Frameworks](#pmf)
5. [Modern Tech Stack Decisions by Stage](#tech-stack)

---

<a name="jobs"></a>
## 1. Steve Jobs — Product Philosophy

Three principles from Mike Markkula's founding memo that Jobs lived by:

### Empathy
Understand customer needs better than anyone — better than they understand themselves. Don't ask customers what they want; observe what frustrates them and what delights them.

### Focus
Eliminate all unimportant opportunities. When Jobs returned to Apple, he killed 70% of the product line, reducing everything to a simple 2×2 grid:

|  | Consumer | Professional |
|---|---|---|
| **Desktop** | iMac | Power Mac |
| **Portable** | iBook | PowerBook |

The diagnostic question for any feature or product line: "If we removed this, would the core experience improve?" If the answer is even "maybe," remove it.

### Impute
Presentation signals quality. People do judge books by their covers. Every touchpoint — packaging, UI, onboarding, invoices — communicates either "we care about every detail" or "we don't."

### Jobs' Design Standard
"Design is not just what it looks like. Design is how it works." If users need a manual, the design has failed. If they need training, the UX isn't intuitive enough.

---

<a name="lean-startup"></a>
## 2. Eric Ries — Lean Startup

### Build-Measure-Learn Loop

Plan in reverse order: start with what you need to **Learn**, determine what to **Measure**, then figure out the minimum to **Build**.

```
BUILD (MVP) → MEASURE (data) → LEARN (insight) → repeat
         ↑________________________↓
```

Most teams run this loop backwards — they build what they want, measure what's easy, and learn nothing.

### MVP Types (from lightest to heaviest)

| Type | Description | Example |
|------|-------------|---------|
| Landing page | Describe the product, collect email signups | Buffer validated demand with a landing page before writing code |
| Explainer video | Show the product concept in a video | Dropbox's famous demo video drove 75K signups overnight |
| Concierge | Deliver the service manually to a few users | Food on the Table had the founder personally shopping groceries |
| Wizard of Oz | Looks automated, humans do the work behind the scenes | Zappos initially fulfilled orders by buying shoes from retail stores |
| Single-feature | Build just one core feature | Twitter started as just 140-character status updates |

### Innovation Accounting

When traditional metrics (revenue, users) are near zero, measure progress with:
- **Actionable metrics** — show cause-and-effect ("changes to onboarding flow improved Day-7 retention by 12%")
- NOT **vanity metrics** — look good but don't inform decisions ("we have 10K downloads" — but how many are active?)

### The Pivot or Persevere Decision

**Signals to pivot:**
- Key metrics don't improve despite multiple iterations
- Core hypotheses fail to validate
- Customer conversations reveal a different, more pressing problem

**Signals to persevere:**
- Metrics trend upward, even slowly
- Core hypotheses validate
- A subset of users is deeply engaged

**Ten pivot types:** zoom-in (one feature becomes the whole product), zoom-out (product becomes one feature of a larger product), customer segment, customer need, platform, business architecture, value capture, engine of growth, channel, and technology.

---

<a name="cagan"></a>
## 3. Marty Cagan — Empowered Product Teams

### The Feature Factory Anti-Pattern

Most product orgs are "feature factories" where:
- PMs become backlog administrators
- Engineers code what's spec'd without contributing to discovery
- Success is measured by features shipped, not outcomes achieved
- Roadmaps are output lists, not problem statements

This wastes half the team's potential. Engineers contribute half their value in discovery — using them only to code is like paying a surgeon to bandage cuts.

### Three Questions to Diagnose Team Empowerment

1. **Are you staffed with competent cross-functional members?** (PM, design, engineering)
2. **Are you assigned problems to solve, not feature lists?** ("Reduce onboarding time to under 5 minutes" vs. "Build a new tutorial wizard")
3. **Are you accountable for business outcomes, not shipping features?** ("Improve conversion by 15%" vs. "Launch feature X by Q2")

If the answer to any of these is "no," the team is a feature factory, not an empowered product team.

### Product Discovery

Run continuously alongside delivery. Test four risks before building anything:

| Risk | Question | Test method |
|------|----------|-------------|
| **Value** | Will customers buy/use it? | Customer interviews, demand tests, fake door tests |
| **Usability** | Can customers figure it out? | Prototype testing, usability tests |
| **Feasibility** | Can we build it? | Technical spike, architecture review |
| **Viability** | Does it work for our business? | Financial modeling, legal review, stakeholder alignment |

---

<a name="pmf"></a>
## 4. Product-Market Fit Frameworks

PMF is the most consequential diagnostic in the entire toolkit. Without it, everything else is theater.

### The Sean Ellis Test

Ask active users: **"How would you feel if you could no longer use this product?"**
- **40%+ answer "very disappointed"** → You have PMF
- **25–40%** → Getting close, focus on the "very disappointed" segment
- **Below 25%** → No PMF yet, don't scale

### The Superhuman PMF Engine (5 steps)

Rahul Vohra's systematic process that moved Superhuman from 22% → 58% "very disappointed":

1. **Survey active users** with four questions:
   - How would you feel if you could no longer use the product? (Very disappointed / Somewhat / Not)
   - What type of people do you think would benefit most from this product?
   - What is the main benefit you receive from the product?
   - How can we improve the product for you?

2. **Segment by "very disappointed" respondents** — these are your High-Expectation Customers (HXC). Build your persona around them, not the average user.

3. **Analyze feedback patterns:**
   - Double down on what champions love
   - Address blockers for "somewhat disappointed" users who share the same main benefit as champions

4. **Build a 50/50 roadmap:**
   - 50% strengthening what already works (delight your champions more)
   - 50% removing blockers (convert "somewhat" to "very disappointed")

5. **Re-survey quarterly** to track the PMF score over time.

### Marc Andreessen's Insight

"When a great team meets a lousy market, market wins." Market matters more than team or product. The first job is to confirm the market is real and large enough.

### Dan Olsen's PMF Pyramid

Five stacked layers, each dependent on the one below:

```
        ┌─────────────┐
        │     UX      │
      ┌─┴─────────────┴─┐
      │   Feature Set    │
    ┌─┴──────────────────┴─┐
    │  Value Proposition    │
  ┌─┴───────────────────────┴─┐
  │    Underserved Needs       │
┌─┴────────────────────────────┴─┐
│       Target Customer           │
└─────────────────────────────────┘
```

Start from the bottom. If Target Customer is wrong, nothing above it matters.

---

<a name="tech-stack"></a>
## 5. Modern Tech Stack Decisions by Stage

### Stage-Appropriate Progression

**Pre-revenue:**
- Frontend: Next.js / React
- Database: PostgreSQL
- Auth: Firebase Auth or Clerk
- Payments: Stripe
- Analytics: PostHog
- Use startup credits aggressively (AWS, GCP, and Vercel all offer them)

**Seed:**
- Add: Redis caching, Mixpanel (behavioral analytics), HubSpot (CRM), CI/CD pipeline

**Series A:**
- Microservices emerging for independent scaling
- Terraform for infrastructure-as-code
- SOC 2 compliance begins (enterprise sales requirement)

**Growth / Series B+:**
- Kubernetes for orchestration
- Multi-region deployment
- Snowflake / BigQuery for data warehouse
- Design system for UI consistency

### The Universal Build-vs-Buy Rule

| Always Buy | Always Build |
|-----------|-------------|
| Auth & identity | Core product logic |
| Payments processing | Proprietary algorithms |
| Email / SMS delivery | Primary user experience |
| Monitoring & observability | Domain-specific workflows |
| CRM | Competitive differentiators |

### Technical Debt Management

Allocate 15–20% of engineering capacity continuously to tech debt. Never let it accumulate into a "tech debt sprint" — that's a sign the debt was already out of control.

Replatform only when maintaining the current system exceeds the cost of rebuilding. This threshold is almost always later than engineers think and earlier than executives think.
