# Growth & Acquisition Frameworks

## Table of Contents
1. [Hormozi's Value Equation & Grand Slam Offer](#hormozi)
2. [Hormozi's $100M Leads](#hormozi-leads)
3. [Brunson's Value Ladder & Funnels](#brunson)
4. [Godin's Purple Cow & Permission Marketing](#godin)
5. [Thiel's Zero to One & Monopoly Theory](#thiel)
6. [Hoffman's Blitzscaling](#hoffman)
7. [YC Growth Benchmarks](#yc-growth)

---

<a name="hormozi"></a>
## 1. Alex Hormozi — Value Equation & Grand Slam Offer

### The Value Equation

```
Value = (Dream Outcome × Perceived Likelihood of Achievement) / (Time Delay × Effort & Sacrifice)
```

Every offer improvement maps to one of these four levers:
- **Increase Dream Outcome** — make the promise bigger and more desirable
- **Increase Perceived Likelihood** — add proof, guarantees, credentials
- **Decrease Time Delay** — deliver results faster
- **Decrease Effort & Sacrifice** — make it easier for the customer

The diagnostic question: "If I described this offer to a stranger, would they say 'How is that even possible?'" If not, the value stack isn't strong enough.

### Grand Slam Offer Construction (step by step)

1. **Pick a starving market** with massive pain, purchasing power, and easy targeting
2. **List every obstacle** between the customer and the dream outcome — be exhaustive
3. **Create solutions** for each obstacle (these become the components of your offer)
4. **Stack the solutions** into a single offer where perceived value is 10–100× the price
5. **Enhance** with:
   - **Scarcity** — limited quantity ("only 10 spots")
   - **Urgency** — limited time ("enrollment closes Friday")
   - **Bonuses** — add high-perceived-value items that cost you little
   - **Guarantees** — reverse the risk entirely (unconditional, conditional, or anti-guarantee)

### Practical application for the operating partner

When entering a company with a weak offer:
- Run the Value Equation on the current offer — score each lever 1–10
- Identify the weakest lever (usually Time Delay or Perceived Likelihood)
- Rebuild the offer using the Grand Slam process
- Test with 20 prospects before rolling out

---

<a name="hormozi-leads"></a>
## 2. Alex Hormozi — $100M Leads Framework

### The four core lead generation methods

Arranged on two axes: warm/cold × 1-to-1/1-to-many:

| | 1-to-1 | 1-to-many |
|---|---|---|
| **Warm** | Warm outreach (DMs, calls to network) | Free content (posts, videos, podcasts) |
| **Cold** | Cold outreach (cold email, cold calls) | Paid ads (Meta, Google, LinkedIn) |

### The Rule of 100

Perform 100 primary outreach actions per day. This is non-negotiable for early-stage companies:
- 100 cold emails, OR
- 100 cold calls, OR
- 100 pieces of content, OR
- $100/day in ads

### Scaling through "Lead Getters"

Once you've mastered one channel yourself, scale through four types of lead getters:
1. **Customers** — referral programs, affiliate structures
2. **Employees** — trained sales reps replicating your process
3. **Agencies** — outsourced lead generation
4. **Affiliates** — partners incentivized by commissions

**Critical rule:** Master one channel profitably before adding the next. Companies that scatter across channels before mastering one waste capital and learn nothing.

---

<a name="brunson"></a>
## 3. Russell Brunson — Value Ladder & Funnel Diagnostics

### The Value Ladder

Structure monetization as a stepped sequence where each rung builds trust for the next:

```
Free Bait (lead magnet)  →  Frontend ($1–47)  →  Core Offer ($97–997)  →  Backend ($1K–25K+)  →  Continuity (recurring)
```

Most companies fail because they only have one rung. The diagnostic: "What happens after someone buys your main product?" If the answer is "nothing," the value ladder is broken.

### Hook-Story-Offer: The Universal Funnel Diagnostic

Every underperforming funnel has one of three problems:

| Symptom | Diagnosis | Fix |
|---------|-----------|-----|
| Low traffic | **Hook problem** — not stopping the scroll | Rewrite headlines, thumbnails, subject lines |
| Traffic but no conversions | **Story problem** — not building belief | Improve case studies, narrative, social proof |
| Interest but no sales | **Offer problem** — not compelling enough | Rebuild using Hormozi's Value Equation |

### Dream 100 Strategy

Identify the top 100 influencers, podcasters, communities, and media outlets where ideal customers already congregate. Then systematically:
1. Engage with their content (provide value first)
2. Build genuine relationships
3. Create collaborations or buy access (sponsorships, guest posts, joint ventures)

This is slower than paid ads but builds durable, compounding audience access.

---

<a name="godin"></a>
## 4. Seth Godin — Purple Cow & Permission Marketing

### Purple Cow Principle

Remarkability must be engineered into the product itself — it's not a marketing layer. The opposite of remarkable isn't "terrible" — it's "very good," because very good is invisible in a crowded market.

Target **sneezers** (innovators and early adopters who spread ideas), not the mass market. Design the product so sneezers can't help but talk about it.

Diagnostic: "Would our customers spontaneously describe this product to a friend at dinner?"

### Permission Marketing

Two types of marketing attention:
- **Permission** (anticipated, personal, relevant) — email lists, podcasts, communities. These assets compound over time.
- **Interruption** (ads, cold calls, spam) — costs escalate over time.

Build permission assets first. Interruption marketing has a place (especially for cold traffic), but a business that relies entirely on interruption is fragile.

Diagnostic: "Do our customers anticipate and welcome our communications?"

---

<a name="thiel"></a>
## 5. Peter Thiel — Zero to One & Monopoly Theory

### The Four Moat Characteristics

Evaluate competitive defensibility through four lenses:

1. **Proprietary technology** — must be 10× better in at least one critical dimension, not marginally better. A 2× improvement looks like noise; 10× is undeniable.

2. **Network effects** — the product must be valuable to the very first users even when the network is small. If it requires critical mass to work, you won't get there. Start with a tiny complete network (Facebook → Harvard, then Ivy League, then all colleges).

3. **Economies of scale** — marginal costs approaching zero. Software scales perfectly; services don't. If adding the next customer costs as much as acquiring the last one, the business won't compound.

4. **Brand** — only effective when combined with the other three. Brand alone is a weak moat (competitors copy positioning). Brand + proprietary tech + network effects = powerful moat.

### The Monopoly Thesis

All successful companies are monopolies solving unique problems. All failures are companies that couldn't escape competition. The playbook:
1. Start small and **monopolize a tiny niche**
2. Expand into **adjacent markets** from a position of strength
3. Don't compete — create a new category

Diagnostic: "Is this product 10× better in at least one critical dimension? Is the company dominating a small, well-defined market before expanding?"

---

<a name="hoffman"></a>
## 6. Reid Hoffman — Blitzscaling

### The Five Organizational Stages

| Stage | Size | Management approach |
|-------|------|-------------------|
| Family | 1–9 | Everyone does everything, direct communication |
| Tribe | 10–99 | Specialists emerge, culture must be intentional |
| Village | Hundreds | Middle management needed, written processes |
| City | Thousands | Functional orgs, executive team, internal politics |
| Nation | Tens of thousands | Business units, autonomous divisions |

Each transition breaks what worked at the previous stage. The management approaches that built a great Tribe will destroy a Village.

### When to Blitzscale (all four must be true)

1. **Winner-take-all market dynamics** — first mover advantage is decisive
2. **Strong network effects** — each user makes the product more valuable
3. **Confirmed product-market fit** — you know the market wants this
4. **Sufficient capital** — blitzscaling is controlled burning of cash for speed

If even one condition is missing, blitzscaling is just burning money fast.

### The Four Growth Factors and Two Growth Limiters

**Factors:** Market size, distribution advantage, high gross margins, network effects
**Limiters:** Lack of product-market fit, lack of operational scalability

### Counterintuitive Blitzscaling Rules

- "Let fires burn" — focus only on existential fires, ignore the rest
- "Launch a product that embarrasses you" — speed beats polish
- "Ignore customers" when speed matters more than individual satisfaction
- "Tolerate bad management" temporarily — you can fix culture later, but you can't un-lose a market

These rules are dangerous outside of true blitzscaling conditions. Apply them only when all four conditions above are confirmed.

---

<a name="yc-growth"></a>
## 7. Y Combinator Growth Benchmarks

### Weekly growth targets during a batch

| Growth rate | Assessment |
|------------|------------|
| 5–7% weekly revenue growth | Good |
| 10%+ weekly | Exceptional |
| 7% weekly sustained | = 33× annual growth |

### The YC sequence

1. **Make something people want** — nothing else matters until this is true
2. **Do things that don't scale** — manually recruit users, provide extraordinary white-glove service
3. **Measure real metrics** — revenue, active users, retention. Not page views, downloads, or signups
4. **Hit growth targets weekly** — treat growth like a heartbeat; if it stops, the company is dying

Paul Graham's operating advice: "Pick a growth rate, then ask every week: what is the ONE thing I must do to hit it?"

The power of compounding: at 7% weekly, $1K MRR becomes $33K MRR in one year. Most founders underestimate compounding and overestimate what they can do in a week.
