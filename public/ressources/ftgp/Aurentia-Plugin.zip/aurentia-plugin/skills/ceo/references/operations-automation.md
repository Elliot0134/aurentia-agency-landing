# Operations, Automation & AI Frameworks

## Table of Contents
1. [The AI Automation Stack (2025–2026)](#ai-stack)
2. [Common AI Automation Workflows](#ai-workflows)
3. [McKinsey's 7S Framework](#mckinsey-7s)
4. [McKinsey's Three Horizons](#three-horizons)
5. [BCG Growth-Share Matrix](#bcg)
6. [Toyota's Lean Principles for Digital](#lean)
7. [Process Automation ROI & Build-vs-Buy](#automation-roi)

---

<a name="ai-stack"></a>
## 1. The AI Automation Stack (2025–2026)

Three platforms dominate, each suited to a different stage:

### Zapier
- **Integrations:** 8,000+
- **Best for:** Non-technical teams needing quick app-to-app connections
- **Pricing:** $20+/month, per-task pricing
- **Limitation:** Becomes expensive at scale due to per-task pricing
- **Stage:** Startup / quick wins

### Make (formerly Integromat)
- **Integrations:** 1,500+
- **Best for:** Moderate complexity with visual canvas builder
- **Pricing:** ~$9/month, 3× better cost efficiency than Zapier
- **Strength:** Superior branching logic and conditional workflows
- **Stage:** Growth

### n8n
- **Valuation:** $1.5B
- **Best for:** Technical teams needing AI-native workflows
- **Pricing:** Self-hostable, free for unlimited executions on own servers; per-execution (not per-step) on cloud
- **Strength:** 70+ AI nodes with LangChain integration, up to 1,000× cheaper for complex automations
- **Stage:** Scale

### Recommended progression
```
Startup → Zapier (quick wins, validate the workflow)
Growth  → Make (cost optimization, more complex logic)
Scale   → n8n self-hosted (AI-heavy, maximum control, lowest cost)
```

---

<a name="ai-workflows"></a>
## 2. Common AI Automation Workflows

### Lead Qualification
```
Inbound form → LLM scores and enriches → Routes to CRM → Auto-sends personalized follow-up
```
Impact: Reduces time-to-response from hours to minutes, increases qualification accuracy.

### Customer Support Triage
```
Ticket arrives → LLM classifies intent and urgency → Routes to right team or auto-responds
```
Impact: Handles 40–60% of L1 tickets without human intervention.

### Content Generation Pipeline
```
Brief → LLM draft → Human review → Auto-publish across channels
```
Impact: 5–10× content output with same team size.

### Intelligent Reporting
```
Scheduled data pull → LLM trend analysis → Narrative report → Auto-distribution
```
Impact: Eliminates manual reporting cycles, surfaces insights humans miss in raw data.

### AI Cost Deflation (Sam Altman's prediction)
AI costs are deflating at 10× every 12 months — faster than Moore's Law. This means:
- Automations that are uneconomical today become viable within 1–2 quarters
- Plan automation strategies assuming costs will drop 10× within a year
- AI agents will "join the workforce" as virtual employees
- Intelligence will become "too cheap to meter"

---

<a name="mckinsey-7s"></a>
## 3. McKinsey's 7S Framework

Diagnoses organizational alignment across seven elements:

### Hard elements (directly manageable)
- **Strategy** — the plan for competitive advantage
- **Structure** — organizational chart, reporting lines
- **Systems** — processes, IT systems, workflows

### Soft elements (equally critical, harder to manage)
- **Shared Values** — core beliefs and culture (center of the model)
- **Skills** — distinctive capabilities of the organization
- **Style** — leadership approach and management behavior
- **Staff** — people, hiring, development

### How to use it

All seven elements must align for effectiveness. When something isn't working:
1. Map the current state of each element
2. Identify misalignments (usually Strategy says one thing but Systems or Staff do another)
3. Fix the alignment, starting with Shared Values (culture) as the anchor

During digital transformation, **Shared Values and Culture** is the most commonly overlooked element, which explains why ~70% of change initiatives fail. Technology is the easy part; getting people aligned is the hard part.

---

<a name="three-horizons"></a>
## 4. McKinsey's Three Horizons

Resource allocation across time horizons:

| Horizon | Focus | Allocation | Timeframe |
|---------|-------|-----------|-----------|
| H1 | Core business (today's cash flow) | ~70% | 0–12 months |
| H2 | Emerging businesses (tomorrow's growth) | ~20% | 12–36 months |
| H3 | Future options (disruptive bets) | ~10% | 36+ months |

The common mistake: all resources go to H1, and the company gets disrupted because H2 and H3 were starved. The operating partner's role is to ensure the portfolio is balanced and that H2/H3 initiatives have executive sponsorship and clear metrics (different from H1 metrics).

---

<a name="bcg"></a>
## 5. BCG Growth-Share Matrix

Classify products/business units into four quadrants:

| | High Market Share | Low Market Share |
|---|---|---|
| **High Growth** | ⭐ Stars (invest heavily) | ❓ Question Marks (analyze, decide) |
| **Low Growth** | 🐄 Cash Cows (harvest, milk) | 🐕 Dogs (divest or wind down) |

- **Stars** → Fund aggressively, they'll become tomorrow's Cash Cows
- **Cash Cows** → Extract cash to fund Stars and Question Marks
- **Question Marks** → The critical decision: invest to become a Star or cut losses
- **Dogs** → Divest unless they serve a strategic role (brand completeness, etc.)

---

<a name="lean"></a>
## 6. Toyota's Lean Principles Applied to Digital Business

### The 8 Wastes (DOWNTIME) in Tech

| Waste | Manufacturing | Tech/Digital equivalent |
|-------|-------------|----------------------|
| **D**efects | Broken parts | Bugs, broken deployments, rework |
| **O**verproduction | Excess inventory | Features nobody uses (45% of features are never used — Standish Group) |
| **W**aiting | Machine downtime | Blocked on code reviews, approvals, decisions |
| **N**on-utilized talent | Underemployment | Engineers doing manual data entry, PMs doing admin |
| **T**ransportation | Moving materials | Excessive team handoffs, cross-team dependencies |
| **I**nventory | Stockpile | Backlog bloat, unreleased features sitting in branches |
| **M**otion | Unnecessary movement | App-switching, searching for information, context switching |
| **E**xtra processing | Over-engineering | Redundant approvals, over-documentation, gold-plating |

### Key Lean Metrics

- **Cycle time** — how long from "started work" to "delivered to customer"
- **Lead time** — how long from "requested" to "delivered"
- **Throughput** — how many units of work completed per unit of time
- **WIP limits** — constraining work-in-progress to improve flow
- **% value-adding time** — how much of total time is actual value creation vs. waste

The most powerful question for any process: "Of the total time in this workflow, what percentage is the customer actually willing to pay for?"

---

<a name="automation-roi"></a>
## 7. Process Automation ROI & Build-vs-Buy

### Four-Factor Automation Scoring

Score each candidate process 1–3 on:

| Factor | Score 1 | Score 2 | Score 3 |
|--------|---------|---------|---------|
| Frequency | Monthly or less | Weekly | Daily or more |
| Rule-based logic | Lots of judgment | Some rules | Highly rule-based |
| Structured data | Unstructured | Semi-structured | Fully structured |
| Stability | Changes often | Changes sometimes | Rarely changes |

**Interpretation:**
- **10–12:** Automate immediately — high ROI, low risk
- **7–9:** Consider simplified automation, may need hybrid approach
- **4–6:** Defer — too much judgment or variability needed

### ROI Components (commonly undercounted)

| Component | Typical % of total ROI |
|-----------|----------------------|
| Direct labor savings | 40–50% |
| Error reduction | 15–25% |
| Cycle time improvement | 10–20% |
| Scalability benefits | 10–20% |

Typical 12-month automation ROI: 200–400% with payback under 12 months.

### The Build-vs-Buy Decision

One question: **"Is this a core competitive differentiator?"**
- **Yes** → Build it. Own the code, own the advantage.
- **No** → Buy it. Don't waste engineering talent on solved problems.
- **Hybrid** → Most companies land here. Buy the platform, customize the integration.

Always buy: auth, payments, email, monitoring, CRM.
Always build: core product logic, proprietary algorithms, primary user experience.
