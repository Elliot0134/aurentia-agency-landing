# Diagnostics & Failure Patterns

## Table of Contents
1. [Startup Failure Patterns (CB Insights)](#failure-patterns)
2. [Stage-Specific Failure Risks](#stage-risks)
3. [The Startup Death Spiral](#death-spiral)
4. [The First 10 Questions — Deep Dive](#ten-questions)
5. [The First 100 Days — Detailed Playbook](#hundred-days)

---

<a name="failure-patterns"></a>
## 1. Startup Failure Patterns

CB Insights' analysis of 431 VC-backed failures reveals the top causes:

| Cause | Frequency | Notes |
|-------|-----------|-------|
| Ran out of capital | 70% | Usually the final cause, not the root cause |
| Poor product-market fit | 43% | The true root cause in most cases |
| Bad timing | 29% | Too early or too late for the market |
| Wrong team | 23% | Skill gaps, founder conflict, culture problems |
| Got outcompeted | 19% | Beaten on execution, distribution, or resources |
| Unsustainable unit economics | 19% | Growth masked by venture capital |

### Leading Indicators of Death

These signals appear months before the company actually fails:

- **Mosaic score declining 15%** in the year before failure — financial health eroding
- **Partnership activity dropping 44%** — ecosystem loses confidence
- **Headcount shrinking** in the final 6 months — talent sees it coming first
- **Increasing time between fundraising milestones** — each round takes longer
- **Key executive departures** — C-suite flight is the canary in the coal mine

---

<a name="stage-risks"></a>
## 2. Stage-Specific Failure Risks

### Pre-Seed / Seed

| Risk | What it looks like |
|------|-------------------|
| Building without validating demand | 6 months of coding before talking to a customer |
| Founder disagreements | Equity fights, vision misalignment, one founder goes part-time |
| Running out of cash before PMF | Spending on office/team before the product works |
| Taking too long to launch | "We'll launch when it's perfect" — it's never perfect |

**Operating partner intervention:** Force the Lean Startup loop. No code before 20 customer conversations. Launch an MVP in 4–8 weeks. Validate the problem before building the solution.

### Series A

| Risk | What it looks like |
|------|-------------------|
| Premature scaling before confirmed PMF | Hiring 20 salespeople when only the founder can close deals |
| Can't transition from founder-led to repeatable sales | Every deal requires the CEO in the room |
| Hiring too fast | Headcount doubles but revenue doesn't follow |

**Operating partner intervention:** Apply the Sean Ellis test before scaling. Document the sales playbook — if you can't teach it, it's not repeatable. Set a Magic Number target before adding sales headcount.

### Growth Stage

| Risk | What it looks like |
|------|-------------------|
| Unsustainable unit economics masked by growth | Burn Multiple > 3× hidden by impressive top-line numbers |
| Culture breakdown during scaling | The "Tribe" management that worked at 30 people breaks at 100 |
| Inability to build middle management | Founders try to manage 15 direct reports; everything bottlenecks |

**Operating partner intervention:** Audit Burn Multiple and unit economics quarterly. Apply Hoffman's stage transitions — recognize that what worked in the previous stage must evolve. Invest in management training, not just hiring.

### Scale-Up

| Risk | What it looks like |
|------|-------------------|
| Market timing misses | The window of opportunity closes while the company optimizes internally |
| Governance failures | Board dysfunction, lack of financial controls, compliance gaps |
| Customer concentration risk | Top 3 customers = 60% of revenue; losing one is existential |
| Founder bottleneck | Every decision still routes through the founder; org can't function autonomously |

**Operating partner intervention:** Apply Porter's Five Forces quarterly. Diversify revenue across customer segments. Build an executive team that can operate without founder involvement on day-to-day decisions.

---

<a name="death-spiral"></a>
## 3. The Startup Death Spiral

The pattern is predictable:

```
Existential shock (market shift, lost customer, funding rejection)
    ↓
Uncertainty (team doesn't know the plan)
    ↓
Team confusion (priorities conflict, meetings multiply)
    ↓
Desperate bets (pivot to whatever seems hot)
    ↓
Resource drain (spreading thin across too many initiatives)
    ↓
Talent flight (best people leave first — they have options)
    ↓
Capital dry-up (investors see the above and pass)
    ↓
Death
```

### Breaking the Spiral

The intervention point is between "Uncertainty" and "Team confusion." The operating partner's job:
1. **Name the situation** honestly (Stockdale Paradox — confront brutal facts)
2. **Prioritize ruthlessly** — kill everything except the ONE initiative that can save the company
3. **Communicate the plan** clearly and repeatedly — certainty (even about a hard path) stops the fear
4. **Switch to wartime mode** (Horowitz) — speed and focus over process and consensus

---

<a name="ten-questions"></a>
## 4. The First 10 Questions — Deep Dive

These questions (listed in the main SKILL.md) deserve deeper analysis of what the answers reveal:

### Question 1: "What problem do you solve, for whom, and why now?"
**Good answer:** Specific, narrow, with a clear timing catalyst ("Remote teams need async video because hybrid work is permanent post-COVID, and Zoom fatigue is documented")
**Bad answer:** Vague, broad, no timing hook ("We help businesses communicate better")
**What it reveals:** Whether the founders have genuine market insight or are guessing

### Question 2: "Revenue and growth over 12 months?"
**What to look for:** Monthly cohort data, not just top-line numbers. A company doing $2M ARR growing 10% month-over-month is very different from one doing $2M flat.
**Red flags:** Revenue concentration in one-time deals, "we're about to close a big contract" (always skeptical), or hockey stick projections based on nothing

### Question 3: "Unit economics — CAC, LTV, payback?"
**If they can't answer:** That IS the answer. It means either (a) they haven't measured, or (b) the numbers are bad and they're avoiding them.
**If they can answer:** Compare against benchmarks in `references/finance-fundraising.md`

### Question 4: "Top 5 customers — what do they say?"
**What to look for:** Do all 5 customers describe the product the same way? If Customer 1 says "it's a communication tool" and Customer 3 says "it's a project management tool," the positioning is broken.
**Gold standard:** Ask to speak directly with 2–3 customers. The founder's filter always adds spin.

### Question 5: "Burn rate and runway?"
**Context matrix:**
- 18+ months runway: peacetime, time to experiment
- 12–18 months: healthy urgency, should be optimizing
- 6–12 months: need a plan for the next raise
- < 6 months: wartime, every decision is about survival

### Question 6: "Team — who's here, who's missing, retention?"
**Key roles to check:** CTO (is the technical foundation solid?), VP Sales (can they sell beyond founder-led?), Head of Product (is product discovery happening?), CFO/Controller (are the finances controlled?)
**Retention red flag:** Any executive departure in the last 6 months without a clear, positive reason

### Question 7: "What keeps you up at night?"
**Listen for:** Whether the answer matches what the data says. If the data shows churn is the problem but the CEO is worried about a competitor, there's a disconnect.
**Best answer:** Honest, specific, and matched to reality. Worst answer: "Nothing, we're executing well" (either delusional or dishonest)

### Question 8: "What's your competitive moat?"
**Apply Thiel's 4 tests.** Most companies claim brand or "our team" as a moat. Neither is durable unless backed by proprietary tech, network effects, or scale advantages.

### Question 9: "Top 3 priorities for the next 90 days?"
**If they list more than 3:** No prioritization discipline. Help them stack-rank.
**If they list fewer than 3:** Either very focused (good) or haven't planned (bad — check which)

### Question 10: "If you could change one thing?"
**This is the truth serum.** The answer usually reveals the problem the founder knows exists but has been avoiding — often a people decision (fire someone, replace a co-founder, restructure a team).

---

<a name="hundred-days"></a>
## 5. The First 100 Days — Detailed Playbook

### Days 1–30: Listen and Learn

**Week 1–2: The Listening Tour**
- Meet every team lead individually (1-hour sessions)
- Ask the same 5 questions to everyone:
  1. What's working well?
  2. What's broken?
  3. If you were CEO, what would you change first?
  4. What do customers love?
  5. What do customers complain about?
- The patterns in the answers reveal more than any dashboard

**Week 2–3: Baseline Everything**
- Financial: monthly P&L, unit economics, cash position, burn
- Growth: MRR/ARR trends, cohort analysis, channel performance
- Product: NPS, feature usage, support ticket patterns
- Team: org chart, compensation benchmarks, engagement signals
- Customer: top 10 customer interviews, churn analysis, expansion patterns

**Week 3–4: Map and Diagnose**
- Map the customer journey end-to-end (first touchpoint to renewal)
- Apply "5 Whys" to the top 3 problems identified in the listening tour
- Assess team strengths, gaps, and flight risks
- **Change nothing yet** — the temptation to act is strong, but premature action wastes the diagnostic window

### Days 31–60: Align and Architect

**Build the Value Creation Plan (VCP)**

Every initiative must trace to one of four value drivers:

| Value Driver | Examples |
|-------------|---------|
| Revenue growth | New markets, pricing optimization, sales expansion |
| Margin expansion | Automation, vendor renegotiation, process efficiency |
| Multiple improvement | Category creation, narrative positioning, governance |
| Risk reduction | Customer diversification, compliance, talent retention |

**Define the Operating Cadence**
- Weekly: leadership standup (30 min), key metrics review
- Monthly: board-level dashboard, P&L review, initiative progress
- Quarterly: strategy review, OKR reset, portfolio rebalancing

**Quick Wins (2–3)**
Identify wins that are:
- Achievable in 2–4 weeks
- Visible to the whole organization
- Aligned with the VCP themes
- Build credibility and trust for the larger changes ahead

### Days 61–100: Lead and Launch

**Launch 1–2 Top Initiatives**
- Each initiative has: clear owner, KPIs, weekly check-in cadence, 90-day milestone
- Staff with the best people — don't delegate the most important work to the weakest team

**First Board Update**
- Present: diagnostic findings, VCP, quick win results, initiative roadmap
- Be honest about what you found — boards respect candor more than spin

**Systems Over Heroics**
- Replace "someone stayed up all night to fix it" with automated monitoring and alerting
- Replace "the CEO approved it personally" with documented decision rights
- Replace "we know because we've been here a long time" with dashboards and documented processes

**The Golden Year Principle**
A world-class VCP front-loads value creation — achieving 50–80% of the total transformation target in Year 1 run-rate. The operating partner's role is to ensure momentum peaks in Year 1, not Year 3.
