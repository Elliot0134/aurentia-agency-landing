# Finance, Unit Economics & Fundraising

## Table of Contents
1. [Core SaaS Metrics & Benchmarks](#saas-metrics)
2. [David Sacks' Burn Multiple](#burn-multiple)
3. [Fundraising Benchmarks by Stage](#fundraising)
4. [Venture Math Essentials](#venture-math)
5. [Revenue Model Economics](#revenue-models)

---

<a name="saas-metrics"></a>
## 1. Core SaaS Metrics & Benchmarks

### LTV:CAC Ratio

| Ratio | Assessment |
|-------|-----------|
| < 1:1 | Losing money on every customer — unsustainable |
| 1:1 – 3:1 | Inefficient, needs improvement |
| **3:1** | **Healthy target** (median B2B SaaS: 3.2:1) |
| 5:1+ | Efficient, but above 5:1 may signal underinvestment in growth |

### CAC Payback Period (Bessemer benchmarks)

| Payback | Rating |
|---------|--------|
| 0–6 months | Best — capital-efficient growth |
| 6–12 months | Better — healthy |
| 12–18 months | Good — acceptable for enterprise |
| 18+ months | Concerning — capital-intensive |

### Net Revenue Retention (NRR)

NRR above 120% is best-in-class and correlates with 2× faster YoY growth. Below 100% signals a leaky bucket — even with great acquisition, you're filling a bathtub with no plug.

| NRR | Signal |
|-----|--------|
| 130%+ | Exceptional — strong expansion revenue |
| 120–130% | Best-in-class |
| 100–120% | Healthy |
| < 100% | Leaky bucket — fix retention before scaling |

### Churn Benchmarks

| Segment | Healthy monthly revenue churn |
|---------|------------------------------|
| Enterprise | < 1% |
| SMB | < 2% |

SMB churn runs 8.2× higher than enterprise. This is structural — SMBs go out of business more often and have lower switching costs.

### Rule of 40

**Growth Rate % + Profit Margin % ≥ 40%**

Applies after reaching ~$15M ARR. Companies above Rule of 40 trade at ~1.7× higher valuation multiples.

Examples:
- 60% growth + (-20%) margin = 40% ✓
- 20% growth + 20% margin = 40% ✓
- 30% growth + (-5%) margin = 25% ✗ (need to either grow faster or improve margins)

### Magic Number

**Net New ARR / Prior Quarter S&M Spend**

| Magic Number | Action |
|-------------|--------|
| < 0.5 | Stop scaling sales — something is fundamentally broken |
| 0.5–0.75 | Investigate — sales efficiency needs work |
| **> 0.75** | **Accelerate — pour fuel on the fire** |
| > 1.5 | You're probably underinvesting in sales |

### T2D3 Framework

Post-$2M ARR growth targets over 5 years:
```
Year 1: Triple   ($2M → $6M)
Year 2: Triple   ($6M → $18M)
Year 3: Double   ($18M → $36M)
Year 4: Double   ($36M → $72M)
Year 5: Double   ($72M → $144M)
```

This is the path to $100M+ ARR and a potential IPO track.

---

<a name="burn-multiple"></a>
## 2. David Sacks — Burn Multiple

### The Formula

```
Burn Multiple = Net Burn / Net New ARR
```

Sacks' signature metric at Craft Ventures. He prefers it over CAC because "there's nowhere to hide" — it captures ALL inefficiency (poor margins, sales waste, high churn, overhead bloat) in a single number.

### Benchmarks

| Burn Multiple | Assessment |
|--------------|-----------|
| < 1× | Amazing — generating more ARR than burning |
| 1–1.5× | Great — efficient growth |
| 1.5–2× | Good — room for improvement |
| 2–3× | Suspect — inefficiency creeping in |
| > 3× | Bad — burning too much relative to growth |

### Sacks' Engagement Benchmarks

| Metric | Target |
|--------|--------|
| DAU/MAU | 40% for B2B |
| DAU/WAU | 60% for B2B |

### Bessemer Efficiency Score (mature companies >$30M ARR)

**FCF Margin + ARR YoY Growth Rate**

| ARR Range | Target efficiency score |
|-----------|----------------------|
| $25–50M | 70% |
| $100M+ | 50% |

---

<a name="fundraising"></a>
## 3. Fundraising Benchmarks by Stage

### Pre-Seed ($500K–$2M raised)
- **What matters:** Team quality, market thesis, early prototype
- **Revenue:** Not typically required
- **Key signal:** Founders have deep domain insight and complementary skills

### Seed ($2.5–$3.2M raised at $14.8–16M pre-money)
- **What matters:** Early PMF signals
- **Revenue:** $20–50K MRR, paying customers
- **Key signal:** Evidence that people will pay for this, even if the numbers are small

### Series A ($9–25M raised at $45–49M pre-money)
- **What matters:** Clear PMF, repeatable customer acquisition
- **Metrics that matter:**
  - $1–2.5M ARR
  - LTV:CAC ≥ 3:1
  - NRR 110–120%
  - CMGR (Compound Monthly Growth Rate) ≥ 10%

### Series B (~$30M raised at ~$166M pre-money)
- **What matters:** Proven unit economics, scalable go-to-market
- **Metrics:**
  - $5–15M+ ARR
  - Burn Multiple < 2×
  - Repeatable sales motion (not just founder-led)

### Series C+ ($50M+ raised)
- **What matters:** Financial maturity, operating leverage, path to profitability
- **Metrics:**
  - $25M+ ARR
  - Improving margins
  - Clear market leadership in segment

### Conversion Rates Between Stages

Only ~9% of 2022 seed-funded startups reached Series A within 3 years, down from 22% for the 2020 cohort. This context matters when evaluating portfolio risk.

AI-native startups command a **42% valuation premium** at seed stage.

---

<a name="venture-math"></a>
## 4. Venture Math Essentials

### Dilution

Typical dilution: ~20% per priced round. Post-money SAFEs (YC standard since 2018) give investors a fixed percentage but stack additively — multiple SAFEs burden founders disproportionately. When advising founders:
- Track total SAFE exposure as a single dilution number
- Model the cap table post-conversion before signing another SAFE
- Beware "SAFE stacking" — 3 SAFEs at $2M each on a $10M cap ≠ 20% total dilution

### VC Power Law Returns

| Outcome | % of portfolio |
|---------|---------------|
| Returns < 1× (loss) | ~33% |
| Returns ~1× (break even) | ~33% |
| Returns 10–100×+ (fund makers) | A handful |

This means: a few massive winners define fund performance. As an operating partner, your job is to identify which companies have the potential to be those winners and focus your energy there.

---

<a name="revenue-models"></a>
## 5. Revenue Model Economics

| Model | Gross Margins | Key metric | Characteristics |
|-------|-------------|------------|-----------------|
| **SaaS** | 75%+ | ARR, NRR | Predictable, recurring, high valuation multiples |
| **Marketplace** | Varies | GMV, take rate (10–30%) | Network effects, winner-take-all dynamics |
| **Freemium** | Depends on base | Conversion rate (2–5% median, 5–10% top) | Large top-of-funnel, low conversion |
| **Usage-based** | High | NRR (+10% vs SaaS), churn (-22% vs SaaS) | Aligns cost with value, but harder to forecast |
| **Services** | 30–50% | Utilization rate, revenue per employee | People-dependent, hard to scale |
| **Hardware** | 20–40% | Units, ASP, margin per unit | Capital-intensive, inventory risk |

Usage-based pricing is increasingly popular because it delivers better NRR and lower churn, but creates forecasting challenges. Hybrid models (base subscription + usage) are becoming the norm.
