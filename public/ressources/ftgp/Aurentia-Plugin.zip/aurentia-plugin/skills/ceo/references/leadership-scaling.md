# Leadership & Scaling Teams

## Table of Contents
1. [Ray Dalio's Principles & Idea Meritocracy](#dalio)
2. [Ben Horowitz — Peacetime vs Wartime CEO](#horowitz)
3. [Patrick Lencioni — Five Dysfunctions & Working Genius](#lencioni)
4. [Naval Ravikant — Leverage Framework](#naval)

---

<a name="dalio"></a>
## 1. Ray Dalio — Principles & Idea Meritocracy

### The Three Pillars

1. **Radical Truth** — everyone speaks hard truths. No one holds critical opinions without voicing them.
2. **Radical Transparency** — information flows freely. Decisions and their reasoning are visible.
3. **Believability-Weighted Decision Making** — decisions weight input by believability, not seniority or volume.

### Defining Believability

Someone is "believable" on a topic when they:
- Have accomplished the thing in question at least three times
- Can explain the cause-effect logic behind their success (not just lucky outcomes)

This prevents both HiPPO decisions (Highest Paid Person's Opinion) and pure democracy (where uninformed votes dilute expert judgment).

### Pain + Reflection = Progress

Every failure is a learning opportunity — but only if you reflect on it honestly. Without reflection, pain just repeats. Dalio's process:
1. Experience the pain (don't avoid or minimize it)
2. Reflect on what caused it (the 5 Whys work here)
3. Identify the principle that prevents recurrence
4. Write down the principle and systematize it

### Implementation Reality

The adaptation period takes roughly 18 months. About two-thirds of people succeed in an idea meritocracy environment; the rest find it too uncomfortable.

**Diagnostic questions:**
- "Can people in your organization speak hard truths without fear of retaliation?"
- "Are decisions made by the most credible people on each topic, or by the loudest or most senior?"
- "When someone fails, is the response blame or systematic learning?"

---

<a name="horowitz"></a>
## 2. Ben Horowitz — Peacetime vs Wartime CEO

### The Two Modes

| Dimension | Peacetime CEO | Wartime CEO |
|-----------|--------------|-------------|
| **Context** | Large competitive advantage, growing market | Existential threat, shrinking runway |
| **Focus** | Big picture, empowering people | Tiny details, micromanaging critical paths |
| **Systems** | Builds scalable processes | Violates protocol to win |
| **Deviation** | Tolerates creative deviations | Intolerant of deviations from the plan |
| **Decisions** | Consensus-seeking, inclusive | Directive, fast, sometimes unilateral |

### Why This Matters for Operating Partners

When entering a company, the first diagnosis is: **Is this a peacetime or wartime situation?**

Signs of wartime:
- Runway < 6 months with no clear funding path
- Major competitor just launched a superior product
- Key customers are churning rapidly
- The team doesn't believe the current strategy will work

The most common mistake: applying peacetime leadership during wartime (being too consultative, too patient, too process-oriented when the house is on fire).

Mastering both modes is the mark of a great CEO. The operating partner's job is to help the CEO recognize which mode they're in and adapt accordingly.

### Management Debt

Short-term shortcuts that create compounding long-term consequences — identical to technical debt:

| Management Debt | Short-term gain | Long-term cost |
|----------------|----------------|---------------|
| Skipping 1:1s | Saves time this week | Lose situational awareness, trust erodes |
| Avoiding hard conversations | Avoids conflict today | Performance problems metastasize |
| Putting two people in a box (ambiguous ownership) | Avoids choosing/confronting | Turf wars, politics, paralysis |
| Promoting for retention, not capability | Keeps someone from leaving | Incompetent managers damage entire teams |

Management debt compounds faster than technical debt because it affects humans who then make worse decisions that create more debt.

---

<a name="lencioni"></a>
## 3. Patrick Lencioni — Five Dysfunctions & Working Genius

### The Five Dysfunctions of a Team (ascending pyramid)

Each dysfunction enables the next. Fix from the bottom up.

```
        ┌─────────────────────────┐
        │  5. Inattention to      │ ← Focus on personal goals over team results
        │     Results             │
      ┌─┴─────────────────────────┴─┐
      │  4. Avoidance of            │ ← Nobody holds peers accountable
      │     Accountability          │
    ┌─┴──────────────────────────────┴─┐
    │  3. Lack of Commitment           │ ← Ambiguity about decisions, no buy-in
    │                                  │
  ┌─┴───────────────────────────────────┴─┐
  │  2. Fear of Conflict                   │ ← Artificial harmony, no real debate
  │                                        │
┌─┴────────────────────────────────────────┴─┐
│  1. Absence of Trust (FOUNDATION)           │ ← People won't be vulnerable
└─────────────────────────────────────────────┘
```

### How to fix each dysfunction

**1. Build Trust:** Requires vulnerability — leaders must go first in sharing weaknesses, mistakes, and fears. Exercises like personal histories and behavioral profiling (DISC, Myers-Briggs) accelerate this.

**2. Enable Conflict:** Establish that productive ideological debate (about ideas) is not personal attacks. Mine for conflict in meetings — if everyone agrees on everything, something is being suppressed.

**3. Create Commitment:** Commitment comes from being heard, not from consensus. After debate, the leader makes the call and everyone commits — even those who disagreed. Clarity beats agreement.

**4. Embrace Accountability:** Must be peer-to-peer, not just leader-to-team. The most effective teams hold each other accountable directly. The leader's role is to create the environment where this is safe.

**5. Focus on Results:** Results must be collective, not individual. When team members optimize for personal metrics (their department, their bonus) over team outcomes, the team fails.

### Working Genius (WIDGET)

Six types of genius across three work phases:

| Phase | Genius types | Description |
|-------|-------------|-------------|
| **Ideation** | **W**onder + **I**nvention | Asking "why?" and generating novel ideas |
| **Activation** | **D**iscernment + **G**alvanizing | Evaluating ideas and rallying people |
| **Implementation** | **E**nablement + **T**enacity | Supporting the work and driving to completion |

Everyone has two geniuses (energizing), two competencies (can do but draining), and two frustrations (avoid).

All six must be present on a team. If a team is heavy on Wonder/Invention but light on Tenacity, they'll generate brilliant ideas that never get finished.

---

<a name="naval"></a>
## 4. Naval Ravikant — Leverage Framework

### The Four Types of Leverage

| Type | Permission needed? | Marginal cost | Example |
|------|-------------------|---------------|---------|
| **Labor** | Yes (need to hire/manage) | High | Employees, contractors |
| **Capital** | Yes (need to raise/earn) | Medium | Investments, loans |
| **Code** | No | Near zero | Software, algorithms, automations |
| **Media** | No | Near zero | Podcasts, YouTube, blogs, social media |

**The paradigm shift:** Old-world fortunes were built on labor and capital (permissioned leverage). New-world fortunes are built on code and media (permissionless leverage) because they require no one's permission and scale infinitely.

### Specific Knowledge

The multiplier that makes leverage valuable:
- Knowledge you **can't be trained for** — it's learned through experience and apprenticeship
- It feels like **play to you** but looks like **work to others**
- It's often at the intersection of multiple fields (the person who understands both AI and healthcare)

### The Wealth Creation Formula

```
Wealth = Specific Knowledge × Leverage × Accountability × Judgment × Compound Interest
```

### Diagnostic for Companies

**"Are we building permissionless leverage (code/media) or relying only on permissioned leverage (labor/capital)?"**

A company with 200 employees doing manual work has permissioned leverage that's expensive and fragile. The same company with 20 people and sophisticated automation has permissionless leverage that scales infinitely.

The operating partner's job is to systematically identify where labor can be replaced by code (automation) and where capital-intensive marketing can be supplemented by media (content, community, brand).

### Naval on Decision-Making

- "If you can't decide, the answer is no." — If a decision is truly close, the expected value of both options is similar; default to the option that preserves optionality.
- "Read what you love until you love to read." — Applied to business: hire people who are drawn to the work, not just capable of it.
- "Play long-term games with long-term people." — Compound interest in relationships, reputation, and knowledge is the most powerful force in business.
