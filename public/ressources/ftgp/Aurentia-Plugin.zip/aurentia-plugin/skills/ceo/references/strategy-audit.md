# Strategic Audit Frameworks

## Table of Contents
1. [Porter's Five Forces](#porter)
2. [TOWS Matrix (Actionable SWOT)](#tows)
3. [Blue Ocean Strategy](#blue-ocean)
4. [Jim Collins' Hedgehog Concept & Flywheel](#collins)
5. [Business Model Canvas & Lean Canvas](#canvas)

---

<a name="porter"></a>
## 1. Porter's Five Forces

Assesses industry-level attractiveness. Each force determines how much profit the industry allows companies to capture.

### The Five Forces in Tech

**1. Competitive Rivalry** (usually strongest in tech)
- High innovation rate, aggressive marketing, winner-take-all dynamics
- Key question: "How many direct competitors exist, and are they well-funded?"

**2. Threat of New Entrants**
- Reduced by: network effects, data moats, regulatory barriers, brand
- Increased by: cloud infrastructure and AI tooling that lower capital requirements
- Key question: "Could a well-funded startup replicate our core product in 12 months?"

**3. Supplier Power**
- Concentrates in specialized talent (AI engineers command premium) and semiconductor producers (TSMC, NVIDIA)
- Key question: "Are we dependent on a single supplier or talent pool that could raise prices or become unavailable?"

**4. Buyer Power**
- Has surged through digital transparency and low switching costs
- Key question: "How easy is it for our customers to leave? What's their switching cost in time, money, and data?"

**5. Threat of Substitutes**
- In tech, entire platform shifts can obliterate product categories overnight (smartphones replaced GPS devices, cameras, and MP3 players simultaneously)
- Key question: "Could a platform shift or technology change make our entire category irrelevant?"

### Common Mistake
Treating Five Forces as a one-time snapshot rather than a dynamic, quarterly reassessment. Markets shift — re-evaluate at least every 90 days during high-growth phases.

---

<a name="tows"></a>
## 2. TOWS Matrix — From Diagnosis to Action

The TOWS Matrix transforms static SWOT into actionable strategy by forcing specific combinations:

| | **Strengths** | **Weaknesses** |
|---|---|---|
| **Opportunities** | **SO strategies** — Leverage strengths to seize opportunities | **WO strategies** — Use opportunities to overcome weaknesses |
| **Threats** | **ST strategies** — Use strengths to mitigate threats | **WT strategies** — Minimize weaknesses to avoid threats |

### How to use it

1. Complete a standard SWOT analysis first
2. For each quadrant, brainstorm 2–3 specific strategic options
3. Each option gets an **owner**, **timeline**, and **milestones**
4. Prioritize by impact and feasibility

The power is in the forced combinations. "We have strong brand (S) and the market is shifting to AI (O)" becomes "Use our brand credibility to launch an AI-powered premium tier" — a specific, actionable SO strategy.

---

<a name="blue-ocean"></a>
## 3. Blue Ocean Strategy

### The Four Actions Framework

| Action | Question | Effect |
|--------|----------|--------|
| **Eliminate** | What factors does the industry take for granted that we can eliminate? | Removes cost and complexity |
| **Reduce** | What factors should we reduce well below industry standard? | Reduces investment in overserved areas |
| **Raise** | What factors should we raise well above industry standard? | Creates differentiation |
| **Create** | What factors should we create that the industry has never offered? | Opens new value space |

Eliminate and Reduce **fund** Raise and Create. Blue ocean strategy isn't about spending more — it's about spending differently.

### The Strategy Canvas

A visual tool that plots competitive factors on the X-axis and offering level on the Y-axis. Each company gets a "value curve."

A good strategy canvas shows three things:
1. **Focus** — not competing on everything (few peaks, not a flat line)
2. **Divergence** — a unique shape, not a copy of competitors
3. **Compelling tagline** — the strategy can be expressed in one sentence

**Example:** Southwest Airlines focused on just three factors (price, friendliness, speed of check-in) while competitors competed on ten. Their value curve diverged sharply — low on meals, lounges, and seat choice; high on fun, frequency, and price.

### How the operating partner uses it

1. Draw the current strategy canvas for the company and its top 3 competitors
2. Identify where everyone clusters (the "red ocean" of competition)
3. Apply the Four Actions Framework to design a divergent value curve
4. Test the new positioning with the target customer segment before committing

---

<a name="collins"></a>
## 4. Jim Collins — Hedgehog Concept & Flywheel

### The Hedgehog Concept

The intersection of three circles:

```
        What you're deeply
         passionate about
              ╱    ╲
             ╱      ╲
            ╱  SWEET  ╲
           ╱   SPOT    ╲
What you    ────────────  What drives your
can be best               economic engine
in the world              (profit per X)
```

The "profit per X" formulation matters — it forces you to identify the single economic denominator that drives the business. Walgreens' was "profit per customer visit." What's yours?

This takes years to crystallize, but once found, it's the filter for every decision: "Does this advance our Hedgehog Concept?"

### The Flywheel Effect

Map the 4–6 sequential steps that create a self-reinforcing virtuous cycle. Each push builds on the previous until breakthrough momentum emerges.

**Amazon's flywheel:**
Lower prices → More customers → More sellers → Better selection → More customers → Lower costs → Lower prices → ...

**The operating partner's job:** Help the company identify and map its flywheel, then ensure every initiative pushes in the direction of the flywheel. Random initiatives outside the flywheel destroy momentum.

### The Doom Loop (what to avoid)

The opposite of a flywheel:
- Reactive decisions without a unifying concept
- Frequent direction changes based on the latest trend
- Chasing fads instead of building on a core
- Big, dramatic programs that replace quiet, consistent progress

### The Stockdale Paradox

Balance two simultaneous truths:
1. **Unwavering faith** in ultimate success — "we will prevail in the end"
2. **Discipline to confront brutal facts** of current reality — "and here's how bad things are right now"

Companies that fail either lose faith (give up) or ignore reality (delusional optimism). The great ones hold both truths simultaneously.

---

<a name="canvas"></a>
## 5. Business Model Canvas & Lean Canvas

### Lean Canvas (for startups — Ash Maurya's adaptation)

Replaces four blocks from Osterwalder's original with startup-relevant ones:

| Lean Canvas block | Replaces (from BMC) |
|------------------|-------------------|
| **Problem** | Key Partners |
| **Solution** | Key Activities |
| **Key Metrics** | Key Resources |
| **Unfair Advantage** | Customer Relationships |

The nine blocks: Problem, Solution, Key Metrics, Unfair Advantage, Unique Value Proposition, Channels, Customer Segments, Cost Structure, Revenue Streams.

Each block is a **hypothesis to test**, with the riskiest assumptions validated first. Usually the riskiest are Problem, Customer Segments, and Revenue.

### Business Model Canvas (for established businesses — Osterwalder)

Nine interconnected blocks: Key Partners, Key Activities, Key Resources, Value Propositions, Customer Relationships, Channels, Customer Segments, Cost Structure, Revenue Streams.

Best used as a diagnostic tool to reveal how the nine blocks create and capture value — and where the connections between blocks are weak or contradictory.

### How to use them

**For a new venture or pivot:** Use Lean Canvas. Fill it in 20 minutes (it should be fast — if you're agonizing, you don't know enough yet). Identify the riskiest assumption. Design an experiment to test it. Repeat weekly.

**For an established business audit:** Use Business Model Canvas. Map the current state, then identify which blocks need strengthening and how changes in one block cascade to others.
