# Aurentia — Le copilote business des dirigeants de PME

> **Version 2.0** — 11 skills business clé-en-main.
> Pour dirigeants, freelances, agences, founders qui veulent piloter leur business avec
> Claude sans devenir experts de l'IA.

---

## Ce que tu obtiens

| Skill | À utiliser quand |
|---|---|
| **🎯 aurentia** | Point d'entrée — tu ne sais pas par où commencer. Te route vers le bon skill. |
| **🧠 ceo** | Diagnostic stratégique, frameworks (Hormozi, Thiel, YC…), plan 100 jours, décisions macro |
| **💡 brainstorming** | Idéation, naming, premortem, exploration d'un problème |
| **📑 devis** | Devis, propositions commerciales, cahiers des charges, SOW |
| **💼 vente** | Prospection, discovery call, objections, closing |
| **🧾 facture** | Factures conformes droit FR + relances impayés gradués + prévi tréso |
| **📣 social-media** | Posts LinkedIn, ads, calendrier édito, hooks, case studies |
| **📧 email** | Welcome sequence, drip, newsletter, re-engagement |
| **📅 réunion** | Agendas, comptes-rendus structurés, suivi d'actions |
| **📊 projet** | Cadrage, planning, SOP, automatisation, gestion de tâches |
| **⚖️ contrat** | Contrats de prestation, NDA, CGV, RGPD, mentions légales |

## Comment ça marche

Les skills s'activent **automatiquement** quand tu décris ton besoin à Claude.

Tu n'as **pas besoin de taper de commande** — Claude détecte ce que tu veux faire grâce à
la description de chaque skill et active le bon. Tu peux aussi nommer un skill
explicitement (« utilise le skill facture »).

Exemple :
```
Toi : Mon client X me doit 3500€ depuis 45 jours, il répond plus
Claude : [Active automatiquement le skill « facture », sous-flux relance impayé,
         déroule l'escalade graduée — amicale → ferme → mise en demeure →
         recouvrement, avec templates FR prêts à copier]
```

Tu peux aussi démarrer en pilotage : « Aide-moi avec mon business » → le skill `aurentia`
te présente les 10 autres et t'oriente.

## Philosophie

Ce plugin applique trois règles non négociables :

1. **La décision finale reste humaine.** Les skills proposent, tu disposes. Vérifie toujours
   les chiffres, les sources et les engagements avant action.
2. **Production, pas réflexion à ta place.** Les skills accélèrent ce que tu sais déjà faire.
   Ils ne décident pas de ta stratégie — ils la stress-testent.
3. **Sparring partner, pas yes-man.** Plusieurs skills challengent activement tes idées.
   C'est voulu.

## Adapté au droit français

Les skills `facture` et `contrat` intègrent :
- Mentions légales auto-entrepreneur (art. 293 B CGI)
- TVA intracom B2B (autoliquidation, art. 196 directive 2006/112/CE)
- Pénalités de retard légales (3× taux d'intérêt) + indemnité forfaitaire 40€ (art. D441-5 C. com.)
- Escalade de relance d'impayés selon droit français (mise en demeure LRAR, injonction de payer, CERFA 12946*02)
- Conformité RGPD (registre des traitements, bases légales, droits des personnes)
- Modèles de contrats conformes au Code de commerce français

## Installation

Voir [INSTALLATION.md](INSTALLATION.md).

## Compatible avec

- **Claude Desktop** (Mac/Windows) — usage principal
- **Claude.ai** (web) — via upload du dossier de skills
- **Claude Code** (CLI / IDE) — pour les power users / devs

## Limites connues

- Les skills ne se substituent pas à un expert. Pour le juridique, le fiscal et le comptable
  réglementaire (notamment > 20K€ ou cas internationaux), consulte un professionnel.
- Les skills produisent des brouillons de haute qualité. Le travail final passe toujours
  par ta relecture et ton ajustement de voix.
- Version 2.0 — certains fichiers de référence sont en anglais (concepts universels :
  Value Equation Hormozi, Five Forces Porter, etc.). Traduction FR prévue en v2.1.
- Le bundle MCP inclus est minimal (`filesystem` officiel). Optionnel.

## Support

Questions, retours, suggestions : [aurentia.agency](https://aurentia.agency)

---

© 2026 Aurentia Agency — Distribué librement aux participants de la formation
« Implémenter l'IA ».
